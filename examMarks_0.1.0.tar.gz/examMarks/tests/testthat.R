library(testthat)
library(Team3Package)

test_check("Team3Package")
